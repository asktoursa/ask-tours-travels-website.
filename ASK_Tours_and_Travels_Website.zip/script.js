const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle?.addEventListener('click', () => {
  const open = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
mainNav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle?.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

document.getElementById('enquiryForm')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const name = String(form.get('customerName') || '').trim();
  const type = String(form.get('tripType') || '').trim();
  const destination = String(form.get('destination') || '').trim();
  const date = String(form.get('travelDate') || '').trim();
  const passengers = String(form.get('passengers') || '').trim();
  const lines = [
    'Hello ASK Tours & Travels, I would like a trip quotation.',
    `Name: ${name}`,
    `Trip type: ${type}`,
    `Route / destination: ${destination}`,
    date ? `Travel date: ${date}` : '',
    passengers ? `Passengers: ${passengers}` : ''
  ].filter(Boolean);
  const url = 'https://wa.me/919940543668?text=' + encodeURIComponent(lines.join('\n'));
  window.open(url, '_blank', 'noopener,noreferrer');
});
