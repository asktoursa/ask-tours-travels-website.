ASK TOURS & TRAVELS WEBSITE
============================

FILES
- index.html: website content
- style.css: blue-and-white responsive styling
- script.js: mobile navigation and WhatsApp enquiry form

HOW TO PREVIEW
1. Unzip the downloaded package.
2. Open index.html in a browser. For best testing, upload it to a static host.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository, e.g. ask-tours-travels-website.
3. Upload index.html, style.css, script.js and this README.md to the repository root.
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. Wait for the deployment to finish. The site URL will be shown in Settings -> Pages and will usually look like:
   https://YOUR-USERNAME.github.io/ask-tours-travels-website/
8. Open the URL on your phone and test all links and the enquiry form.

ALTERNATIVE: NETLIFY DROP
1. Open https://app.netlify.com/drop
2. Sign in if requested.
3. Drag and drop the unzipped website folder (the folder containing index.html).
4. Netlify will provide a public website URL. You can change the generated site name in Netlify settings if available.

IMPORTANT
- Hosting on these services can be free under their current terms; provider terms and features may change.
- WhatsApp booking uses the business number 9940543668 in international format (+91 99405 43668).
- The enquiry form opens WhatsApp with the details; it does not store submissions or send them to a database.
- Vehicle tariff information is based on the details supplied. Confirm rates and trip terms before publishing if they have changed.
- Tempo Traveller rate is shown as "Ask for tariff" because no rate was supplied.
- The Munnar/Thekkady/Kodaikanal package has no fixed price because passenger count, dates, vehicle, hotels and inclusions affect the quotation.
- Before promoting the website, check spelling, phone number, address, vehicle rates and terms.
